#include <cassert>
#include <ios>
#include <iostream>
